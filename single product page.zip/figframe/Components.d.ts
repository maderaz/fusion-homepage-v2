// Components.d.ts — the complete catalog of the 1 component(s) in
// Components.bundle.js. READ THIS FILE BEFORE USING THE BUNDLE: component
// names are derived from Figma layer names (sanitized to PascalCase,
// deduplicated) and may differ from what the design calls them — the
// "figma layer" comment above each interface maps them back.
// After the bundle <script> loads, every component is a window global
// (e.g. window.WDefault1897) and usable directly in JSX.
import * as React from 'react';

// figma layer: "1897w default" (node 1:1164)
export interface WDefault1897Props {
  className?: string;
  style?: React.CSSProperties;
}

declare const WDefault1897: React.FC<WDefault1897Props>;
declare global {
  interface Window {
    WDefault1897: React.FC<WDefault1897Props>;
  }
}
